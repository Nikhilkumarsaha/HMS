package com.HMS.HMS.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HMS.HMS.Dto.PatientDto;
import com.HMS.HMS.Repository.PatientRepo;

@Service
public class PatientService {
	
	@Autowired
	PatientRepo repo;
	
	public String signUp(PatientDto dto) {
        long number = dto.getNumber();
        if (repo.findById(number).isPresent()) {
            return "PATIENT ALREADY EXISTS";
        }
        repo.save(dto);
        return "PATIENT DETAILS ADDED SUCCESSFULLY";
    }

    public String login(Long number, String password) {
        Optional<PatientDto> optionalDto = repo.findById(number);
        if (!optionalDto.isPresent()) {
            return "USER ACCOUNT DOES NOT EXIST";
        }
        PatientDto dto = optionalDto.get();
        String encryptPass = dto.getPassword();

        if (password.equals(encryptPass)) {
            return "USER LOGGED IN";
        }
        return "INVALID CREDENTIALS";
    }
	
}
