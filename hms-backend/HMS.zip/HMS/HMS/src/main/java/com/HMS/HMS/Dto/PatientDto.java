//package com.HMS.HMS.Dto;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import lombok.Data;
//
//@Data
//@Entity
//public class PatientDto {
//	@Column(nullable = false)
//	private String name;
//	@Column(nullable = false)
//	private int age;
//	@Column(nullable = false)
//	private String gender;
//	@Column(nullable = false)
//	private String address;
//	@Id
//	private long number;
//	@Column(nullable = false, unique = true)
//	private String email;
//	@Column(nullable = false)
//	private String bloodGroup;
//	@Column(nullable = false)
//	private String password;
//	@Column(nullable = false)
//	private String cpassword;
//}

package com.HMS.HMS.Dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Data
@Entity
public class PatientDto {
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private int age;
	@Column(nullable = false)
	private String gender;
	@Column(nullable = false)
	private String address;
	@Id
	private long number;
	@Column(nullable = false, unique = true)
	private String email;
	@Column(nullable = false)
	private String bloodGroup;
	@Column(nullable = false)
	private String password;
	@Column(nullable = false)
	private String cpassword;

	@Column(nullable = false)
	private String emergencyContact;  // New Field

	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<AppointmentDto> appointments;

}
