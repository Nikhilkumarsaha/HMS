package com.HMS.HMS.Dto;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class DoctorDto {
	@Column(nullable = false)
	private String doctorName;
	@Column(nullable = false)
	private int age;
	@Column(nullable = false)
	private String gender;
	@Id
	private long number;
	@Column(nullable = false)
	private String specialties;
	@Column(nullable = false)
	private String qualification;
	@Column(nullable = false)
	private String certifications;
	@Column(nullable = false)
	private LocalDate date;
	@Column(nullable = false)
	private String password;
	@Column(nullable = false)
	private String role;
}
