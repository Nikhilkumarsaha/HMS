package com.HMS.HMS.Dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class AdminDto {
	@Id
	private String username;
	@Column(nullable = false, unique = true)
	private String email;
	private String password;
	@Column(nullable = false)
	private String cpassword;
	@Column(nullable = false)
	private String role;
	@Column(nullable = false, unique = true)
	private long number;
}
