package com.HMS.HMS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HMS.HMS.Dto.AppointmentDto;
import com.HMS.HMS.Service.AppointementService;

@RestController
@RequestMapping("/Appointements")
public class AppointementController {
	
	@Autowired
	AppointementService service;
	
	@PostMapping("/book/{patientNumber}")
	public String bookAppointment(@RequestBody AppointmentDto appointment, @PathVariable Long patientNumber) {
		return service.bookAppointment(appointment, patientNumber);
	}
	
	@GetMapping("/byPhone/{phoneNumber}")
    public Object getAppointmentsByPhone(@PathVariable Long phoneNumber) {
        List<AppointmentDto> appointments = service.getAppointmentsByPhoneNumber(phoneNumber);
        if (appointments == null) {
            return "DATA NOT FOUND";
        }
        return appointments;
    }
}
