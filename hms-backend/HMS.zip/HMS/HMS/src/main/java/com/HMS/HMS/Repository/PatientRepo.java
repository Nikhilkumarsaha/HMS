package com.HMS.HMS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HMS.HMS.Dto.PatientDto;

public interface PatientRepo extends JpaRepository<PatientDto, Long> {

}
