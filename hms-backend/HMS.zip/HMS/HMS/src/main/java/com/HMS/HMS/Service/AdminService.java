package com.HMS.HMS.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HMS.HMS.Dto.AdminDto;
import com.HMS.HMS.Repository.AdminRepo;

@Service
public class AdminService {
	
	@Autowired
	AdminRepo repo;
	
	public String signUp(AdminDto dto) {
		String username = dto.getUsername();
		if (repo.findById(username).isPresent()) {
			return "USER ALREADY EXISTS";
		} else {
//			dto.setPassword(AES.encrypt(dto.getPassword()));
			repo.save(dto);
			return "USER ACCOUNT CREATED";
		}

	}

	public String logIn(String username, String password, String role) {
	    Optional<AdminDto> optionalDto = repo.findById(username);
	    if (!optionalDto.isPresent()) {
	        return "USER ACCOUNT DOES NOT EXIST";
	    } 
	    AdminDto dto = optionalDto.get();
	    String encryptPass = dto.getPassword(); 
	    String storedRole = dto.getRole();
	    
	    if (password.equals(encryptPass) && role.equals(storedRole)) {
	        return "USER LOGGED IN";
	    } else {
	        return "INVALID CREDENTIALS";
	    }
	}

}
