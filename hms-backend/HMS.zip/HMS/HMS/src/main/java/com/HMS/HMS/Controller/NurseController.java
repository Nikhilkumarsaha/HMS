package com.HMS.HMS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HMS.HMS.Dto.NurseDto;
import com.HMS.HMS.Dto.PatientDto;
import com.HMS.HMS.Service.NurseService;

@RestController
@RequestMapping("/Nurse")
public class NurseController {

	@Autowired
	NurseService service;

	@GetMapping("/patients")
	public List<PatientDto> getAllPatients() {
		return service.getAllPatients();
	}

	@GetMapping("/patients/{phoneNumber}")
	public Object getPatientDetails(@PathVariable Long phoneNumber) {
		return service.getPatientDetails(phoneNumber);
	}
	
	@PostMapping("/signup")
	public String signup(@RequestBody NurseDto dto) {
		return service.signup(dto);
	}
	
	@GetMapping("/login")
	public String login(@RequestBody NurseDto dto) {
		return service.login(dto.getNumber(), dto.getPassword(), dto.getRole());
	}
}
