package com.HMS.HMS.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HMS.HMS.Dto.AppointmentDto;
import com.HMS.HMS.Dto.PatientDto;
import com.HMS.HMS.Repository.AppointementRepo;
import com.HMS.HMS.Repository.PatientRepo;

@Service
public class AppointementService {
	
	@Autowired
	AppointementRepo bookRepo;
	
	@Autowired
	PatientRepo patientRepo;
	
	public String bookAppointment(AppointmentDto appointment, Long patientNumber) {
		Optional<PatientDto> patientOpt = patientRepo.findById(patientNumber);
		if (!patientOpt.isPresent()) {
			return "PATIENT NOT FOUND";
		}

		PatientDto patient = patientOpt.get();
		appointment.setPatient(patient);
		appointment.setStatus("Pending");

		bookRepo.save(appointment);
		return "APPOINTMENT BOOKED SUCCESSFULLY";
	}
	
	public List<AppointmentDto> getAppointmentsByPhoneNumber(Long phoneNumber) {
        List<AppointmentDto> appointments = bookRepo.findByPatientNumber(phoneNumber);
        if (appointments.isEmpty()) {
            return null;
        }
        return appointments;
    }
	
}
