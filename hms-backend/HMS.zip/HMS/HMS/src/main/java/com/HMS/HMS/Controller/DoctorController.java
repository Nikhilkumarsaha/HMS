package com.HMS.HMS.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HMS.HMS.Dto.DoctorDto;
import com.HMS.HMS.Dto.MedicalInfoDto;
import com.HMS.HMS.Service.DoctorService;

@RestController
@RequestMapping("/Doctor")
public class DoctorController {

	@Autowired
	DoctorService service;

	@PostMapping("/signup")
	public String signup(@RequestBody DoctorDto dto) {
		return service.signUp(dto);
	}

	@GetMapping("/login")	
	public String login(DoctorDto dto) {
		return service.login(dto.getNumber(), dto.getPassword(), dto.getRole());
	}
	
//	@PostMapping("/medicalInfo")
//	public String medicalInfo(@RequestBody MedicalInfoDto dto) {
//		return service.saveMedicalInfo(dto);
//	}
	
	 @PostMapping("/medicalInfo")
	    public ResponseEntity<String> addMedicalInfo(@RequestBody MedicalInfoDto dto) {
	        String response = service.saveMedicalInfo(dto);
	        return ResponseEntity.ok(response);
	    }
}
