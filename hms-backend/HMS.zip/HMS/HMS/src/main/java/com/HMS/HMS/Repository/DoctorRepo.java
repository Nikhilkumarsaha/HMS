package com.HMS.HMS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HMS.HMS.Dto.DoctorDto;

public interface DoctorRepo extends JpaRepository<DoctorDto, Long> {


}
