package com.HMS.HMS.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HMS.HMS.Dto.AdminDto;
import com.HMS.HMS.Service.AdminService;

@RestController
@RequestMapping("/Admin")
@CrossOrigin()
public class AdminController {
	@Autowired
	AdminService service;
	
	@PostMapping("/signup")
	public String signUp(@RequestBody AdminDto dto) {
		return service.signUp(dto);
	}

	@PostMapping("/login")
	public String logIn(@RequestBody AdminDto dto) {
	    return service.logIn(dto.getUsername(), dto.getPassword(), dto.getRole());
	}
}
