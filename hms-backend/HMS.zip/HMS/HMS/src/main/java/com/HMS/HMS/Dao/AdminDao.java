package com.HMS.HMS.Dao;

public class AdminDao {

}
