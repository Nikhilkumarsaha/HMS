package com.HMS.HMS.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HMS.HMS.Dto.DoctorDto;
import com.HMS.HMS.Dto.MedicalInfoDto;
import com.HMS.HMS.Dto.PatientDto;
import com.HMS.HMS.Repository.DoctorRepo;
import com.HMS.HMS.Repository.MedicalInfoRepo;
import com.HMS.HMS.Repository.PatientRepo;

@Service
public class DoctorService {

	@Autowired
	DoctorRepo repo;
	
	@Autowired
	PatientRepo patientRepo;	
	
	@Autowired
	MedicalInfoRepo medicalRepo;

	public String signUp(DoctorDto dto) {
	    long number = dto.getNumber();
	    if (repo.findById(number).isPresent()) {
	        return "DOCTOR ALREADY EXISTS";
	    }
	    repo.save(dto);
	    return "DOCTOR DETAILS ADDED SUCCESSFULLY";
	}

	public String login(Long number, String password, String role) {
	    Optional<DoctorDto> optionalDto = repo.findById(number);
	    if (!optionalDto.isPresent()) {
	        return "USER ACCOUNT DOES NOT EXIST";
	    }  
	    DoctorDto dto = optionalDto.get();
	    String encryptPass = dto.getPassword();
	    String storedRole = dto.getRole();

	    if (password.equals(encryptPass) && role.equals(storedRole)) {
	        return "USER LOGGED IN";
	    }
	    return "INVALID CREDENTIALS";
	}
	
	
//	public String saveMedicalInfo(MedicalInfoDto dto) {
//        medicalRepo.save(dto);
//        return "Medical Info Added Successfully";
//    }
	
	public String saveMedicalInfo(MedicalInfoDto dto) {
	    Optional<PatientDto> patientOptional = patientRepo.findById(dto.getPatient().getNumber());
	    if (!patientOptional.isPresent()) {
	        return "Patient does not exist!";
	    }

	    Optional<DoctorDto> doctorOptional = repo.findById(dto.getDoctor().getNumber());
	    if (!doctorOptional.isPresent()) {
	        return "Doctor does not exist!";
	    }

	    Optional<MedicalInfoDto> existingRecord = medicalRepo.findByPatient(dto.getPatient());

	    if (existingRecord.isPresent()) {
	        dto.updateMedicalHistory(existingRecord.get().getCurrentMedications());
	    } else {
	        dto.setMedicalHistory(""); // First-time visit
	    }

	    medicalRepo.save(dto);
	    return "Medical Info Added Successfully";
	}


}
