package com.HMS.HMS.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HMS.HMS.Dto.AppointmentDto;

public interface AppointementRepo extends JpaRepository<AppointmentDto, Integer> {

	List<AppointmentDto> findByPatientNumber(Long phoneNumber);

}
