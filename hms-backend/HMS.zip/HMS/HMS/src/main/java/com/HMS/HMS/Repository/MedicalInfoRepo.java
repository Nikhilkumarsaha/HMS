package com.HMS.HMS.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HMS.HMS.Dto.MedicalInfoDto;
import com.HMS.HMS.Dto.PatientDto;

public interface MedicalInfoRepo extends JpaRepository<MedicalInfoDto, Integer>{

	Optional<MedicalInfoDto> findByPatient(PatientDto patient);

}
