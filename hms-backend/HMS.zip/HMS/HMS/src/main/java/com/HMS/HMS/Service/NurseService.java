package com.HMS.HMS.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HMS.HMS.Dto.NurseDto;
import com.HMS.HMS.Dto.PatientDto;
import com.HMS.HMS.Repository.NurseRepo;
import com.HMS.HMS.Repository.PatientRepo;

@Service
public class NurseService {

	@Autowired
	NurseRepo nurseRepo;

	@Autowired
	PatientRepo patientRepo;

	public List<PatientDto> getAllPatients() {
		return patientRepo.findAll(); // Fetch all patients
	}

	public Object getPatientDetails(Long phoneNumber) {
		Optional<PatientDto> patient = patientRepo.findById(phoneNumber);
		if (patient.isEmpty()) {
			return "DATA NOT FOUND";
		}
		return patient;
	}

	public String signup(NurseDto dto) {
		long number = dto.getNumber();
		if (nurseRepo.findById(number).isPresent()) {
			return "EMAIL ALREADY EXISTS";
		} else {
			nurseRepo.save(dto);
			return "RECEPTIONIST REGISTERED SUCCESSFULLY";
		}
	}

	public String login(long number, String password, String role) {
		Optional<NurseDto> dto = nurseRepo.findById(number);
		if (!dto.isPresent()) {
			return "USER ACCOUNT DOES NOT EXIST";
		}
		NurseDto nurseDto = dto.get();
		String encryptPass = nurseDto.getPassword();
		String storedRole = nurseDto.getRole();
		if (password.equals(encryptPass) && role.equals(storedRole)) {
			return "USER LOGGED IN";
		} else {
			return "INVALID CREDENTIALS";
		}
	}
}
