package com.HMS.HMS.Dto;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Data
@Entity
public class NurseDto {
	@Column(nullable = false)
	private String name;
	@Id
	private long number;
	@Column(nullable = false, unique = true)
	private String email;
	@Column(nullable = false)
	private String qualification;
	@Column(nullable = false)
	private String certificates;
	@Column(nullable = false)
	private String department;
	@Column(nullable = false)
	private String password;
	@Column(nullable = false)
	private String cpassword;
	@Column(nullable = false)
	private String role;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<PatientDto> patients; 
}
