package com.HMS.HMS.Dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Data
@Entity
public class MedicalInfoDto {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(nullable = false)
	private String allergies;
	@Column(nullable = false)
	private String medicalHistory = "";
	@Column(nullable = false)
	private String currentMedications;

	@OneToOne
	@JoinColumn(name = "patient_id", nullable = false)
	private PatientDto patient;

	@ManyToOne
	@JoinColumn(name = "doctor_id", nullable = false)
	private DoctorDto doctor;

	 public void updateMedicalHistory(String previousMedications) {
	        if (previousMedications != null && !previousMedications.isEmpty()) {
	            this.medicalHistory = previousMedications;
	        }
	    }
}
