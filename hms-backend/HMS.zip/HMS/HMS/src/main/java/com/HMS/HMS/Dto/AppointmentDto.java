//package com.HMS.HMS.Dto;
//
//import java.time.LocalDate;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import lombok.Data;
//
//@Data
//@Entity
//public class AppointementDto {
//	@Column(nullable = false)
//	private String name;
//	@Column(nullable = false, unique = true)
//	private String email;
//	@Column(nullable = false, unique = true)
//	private long number;
//	@Column(nullable = false)
//	private String Symptoms;
//	@Column(nullable = false)
//	private LocalDate date;
//	private String status;
//}

package com.HMS.HMS.Dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class AppointmentDto {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String symptoms;

	@Column(nullable = false)
	private LocalDate date;

	@Column(nullable = false)
	private String status = "Pending";

	@Column(nullable = false)
	private String doctorName; 

//	@Column(nullable = false)
	private String department; 

	@Column(nullable = false)
	private String preferredTimeSlot; 

	@ManyToOne
	@JoinColumn(name = "patient_number", nullable = false)
	@JsonBackReference
	private PatientDto patient;

}
